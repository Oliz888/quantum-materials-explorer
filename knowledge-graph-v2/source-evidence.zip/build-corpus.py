"""Build a new version from captured official search pages; no network or repo writes."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import importlib.util, json, hashlib, os
def write_json(path,value):
 temp=path.with_suffix(path.suffix+'.tmp')
 temp.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
 os.replace(temp,path)
BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('nature_audit',BASE/'audit-corpus.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
baseline=json.loads(mod.DEFAULT_BASELINE.read_text())
captured=[];captured_hashes={}
for f in sorted((BASE/'pages').glob('*.json')):
 blob=f.read_bytes();captured.append((f,json.loads(blob)));captured_hashes[str(f)]=hashlib.sha256(blob).hexdigest()
audit=mod.audit(BASE/'pages',mod.DEFAULT_BASELINE,captured)
write_json(BASE/'corpus-audit.json',audit)
old={mod.canon(p['url']):p for p in baseline['papers']}
papers={};sources=[];channel_pages=defaultdict(list)
for file,p in captured:
 slug=p['channelId'];url=p['queryUrl'];page=p['pageNumber'];channel_pages[slug].append(p)
 sources.append({'channelId':slug,'pageNumber':page,'queryYear':p.get('queryYear'),'url':url,'capturedAt':p['capturedAt'],'rawFile':str(file.relative_to(BASE)),'sha256':captured_hashes[str(file)],'resultStart':p['resultStart'],'resultEnd':p['resultEnd'],'officialTotal':p['officialTotal'],'recordCount':len(p['papers'])})
 for r in p['papers']:
  identity=mod.canon(r['url'])
  if identity is None:continue
  if identity not in papers:
   record={'id':'nature-'+identity.rsplit('/',1)[-1],'title':r['title'],'url':identity,'date':r['date'],'year':r['year'],'type':r['type'],'typeGroup':mod.classify(r['type']),'journal':r['journal'],'volumePageInfo':r.get('volumePageInfo'),'doi':r.get('doi'),'channels':[],'sourceUrls':[],'memberships':[],'membershipBasis':'Appears in an official Nature subject search result, within the stated query scope. Membership is recorded separately for every observed subject.'}
   if not record['doi'] and old.get(identity,{}).get('doi'):
    record['doi']=old[identity]['doi'];record['doiEvidence']={'basis':'Previously explicitly verified DOI; not inferred from URL slug.','sourceUrls':old[identity]['sourceUrls'],'snapshotDate':baseline['checkedDate']}
   papers[identity]=record
  record=papers[identity]
  if slug not in record['channels']:record['channels'].append(slug)
  if url not in record['sourceUrls']:record['sourceUrls'].append(url)
  membership={'channelId':slug,'sourceUrl':url,'pageNumber':page,'queryYear':p.get('queryYear'),'date':r['date'],'year':r['year'],'type':r['type'],'journal':r['journal'],'capturedAt':p['capturedAt']}
  if membership not in record['memberships']:record['memberships'].append(membership)
  if record['doi'] is None and r.get('doi'):record['doi']=r['doi']
  for field in ['title','date','year','type','journal','doi']:
   value=r.get(field)
   if value is not None and value!=record[field]:
    variant={'field':field,'value':value,'sourceUrl':url};variants=record.setdefault('metadataVariants',[])
    if variant not in variants:variants.append(variant)
channels=[]
for original in baseline['channels']:
 if original['system']!='nature-ontology':continue
 slug=original['id'];stats=next(c for c in audit['channels'] if c['id']==slug);observed=channel_pages[slug]
 c={k:original[k] for k in ['id','name','system','url','sourceUrl','officialResultsCount','countScope','annualSeries','annualCoverage','aggregateCountsComplete','checkedDate']}
 complete=stats['countMatches'] and stats['primaryComplete'] and not any(i['severity']=='error' and (i.get('channel')==slug or any(str(p.get('file'))==i.get('file') for p in audit['pages'].get(slug,[]))) for i in audit['issues'])
 c.update(loadedCount=stats['retrievedUnique'],paginationComplete=complete,recordPaginationComplete=complete,availability='official-paginated-metadata',recordCoverage={'complete':complete,'retrievedUnique':stats['retrievedUnique'],'expectedTotal':stats['expectedTotal'],'remaining':stats['remaining'],'pagesCaptured':len(observed),'primaryPagesCaptured':stats['primaryPagesCaptured'],'expectedPrimaryPages':stats['expectedPrimaryPages'],'supplementalPagesCaptured':stats['supplementalPagesCaptured'],'yearQueries':stats['years'],'annualCountsMatch':stats['annualCountsMatch'],'typeCounts':stats['typeCounts'],'yearTypeCounts':stats['yearTypeCounts'],'capturedFrom':min((p['capturedAt'] for p in observed),default=None),'capturedThrough':max((p['capturedAt'] for p in observed),default=None)},coverageNote='Individual records collected from the official paginated Nature search for research, reviews and protocols, across Nature Portfolio. Complete status requires official-total and annual-total reconciliation; 2026 is partial through the snapshot date.')
 channels.append(c)
counts_by_year_type=defaultdict(Counter);counts_by_type=Counter();overlaps=Counter()
for r in papers.values():
 counts_by_year_type[r['year']][r['typeGroup']]+=1;counts_by_type[r['typeGroup']]+=1
 for pair in combinations(sorted(r['channels']),2):overlaps[pair]+=1
coverage={'complete':audit['complete'],'uniquePapers':len(papers),'channelMemberships':audit['channelMemberships'],'expectedChannelMemberships':sum(c['officialResultsCount'] for c in channels),'multiChannelPapers':audit['multiChannelPapers'],'pagesCaptured':len(sources),'primaryPagesCaptured':audit['primaryPagesCaptured'],'expectedPrimaryPages':audit['expectedPrimaryPages'],'supplementalPagesCaptured':audit['supplementalPagesCaptured'],'metadataConflictCount':len(audit['metadataConflicts']),'issueCount':len(audit['issues']),'errorCount':sum(i['severity']=='error' for i in audit['issues']),'typeCounts':dict(counts_by_type)}
output={'version':3,'checkedDate':'2026-11-04','scope':{'channelIds':[c['id'] for c in channels],'journalScope':'Nature Portfolio','articleTypeQuery':['protocols','research','reviews'],'startYear':2010,'endYear':2026,'cutoffDate':'2026-11-04','partialYear':2026,'annualTotalsBasis':'Official year-query totals captured in the prior snapshot; full pagination is reconciled against them.','partitionStrategy':'One publication-year query per channel, because the official search interface exposes only the first 1000 results per query. All selected year partitions remain below that limit.','collectionMethod':'Visible official Advanced Search controls followed by official next-page links; each saved page is validated against query year, scope, result count and displayed record dates.','paperIdentity':'Canonical official Nature article URL; DOI only when explicitly sourced.','exclusions':'The separate Nature citation-topic channel and out-of-scope news/comment previews from the earlier version are not merged into this five-subject corpus.'},'channels':channels,'papers':sorted(papers.values(),key=lambda r:(r['date'],r['url']),reverse=True),'coverage':coverage,'yearTypeCounts':{str(y):dict(t) for y,t in sorted(counts_by_year_type.items())},'overlapCounts':[{'subjects':list(k),'count':v,'complete':audit['complete']} for k,v in sorted(overlaps.items())],'sources':sources,'limitations':['Counts represent records classified under these Nature channels, not all quantum-materials research.','The same paper can belong to several channels; channel totals must not be added to infer unique papers.','2026 is year-to-date. Publisher indexing, journal coverage and subject tagging may influence apparent growth.','Subject links do not establish citation flow or intellectual influence.','Complete status applies only to the stated five-channel query scope. The original 243-record preview version remains separate.']}
write_json(BASE/'full-corpus.json',output)
print(json.dumps(coverage,indent=2))

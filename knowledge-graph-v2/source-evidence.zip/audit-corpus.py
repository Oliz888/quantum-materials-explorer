"""Offline audit of official Nature search metadata with publication-year partitions.

All-year pages are supplemental: Nature search exposes only the first 1000 results.
Completeness requires every 2010–2026 year query, including explicit zero evidence.
No collection files are changed and no network requests are made.
"""
from pathlib import Path
from urllib.parse import urlsplit,urlunsplit,parse_qs
from collections import Counter,defaultdict
from datetime import date as calendar_date, datetime
import argparse,json,re,hashlib
BASE=Path(__file__).resolve().parent
DEFAULT_BASELINE=BASE/'baseline.json'
DATE='2026-11-04'
def canon(url):
 s=urlsplit(url or '')
 if s.hostname not in ('www.nature.com','nature.com') or not re.fullmatch(r'/articles/[^/]+/?',s.path):return None
 return urlunsplit(('https','www.nature.com',s.path.rstrip('/'),'',''))
def classify(typ):
 t=(typ or '').lower().strip()
 if 'review' in t:return 'review'
 if 'protocol' in t:return 'protocol'
 if any(k in t for k in ['news','comment','briefing','highlight','editorial','correction','perspective']):return 'other'
 if t in ['research','article','letter','research article']:return 'research'
 return 'unknown'
def flatten(v):
 if isinstance(v,list):return [p for item in v for p in flatten(item)]
 if isinstance(v,dict):
  if isinstance(v.get('pages'),list):return flatten(v['pages'])
  if any(k in v for k in ['papers','records','articles','cards']):return [v]
 return []
def audit(pages_dir,baseline_path,captured_pages=None):
 baseline=json.loads(baseline_path.read_text());channels={c['id']:c for c in baseline['channels'] if c['system']=='nature-ontology'}
 expected_years={c:{r['year']:r['count'] for r in d['annualSeries']} for c,d in channels.items()}
 issues=[];pages=[]
 def issue(kind,**kw):issues.append({'severity':kw.pop('severity','error'),'kind':kind,**kw})
 if captured_pages is not None:
  pages=list(captured_pages)
 else:
  for file in sorted(pages_dir.rglob('*.json')):
   try:found=flatten(json.loads(file.read_text()))
   except Exception as e:issue('invalid-json',file=str(file),message=str(e));continue
   if not found:issue('unrecognized-page-shape',severity='warning',file=str(file))
   for p in found:pages.append((file,p))
 by_channel=defaultdict(dict);primary_by_channel=defaultdict(dict);by_paper=defaultdict(list);groups={}
 for file,p in pages:
  url=p.get('queryUrl') or p.get('sourceUrl') or p.get('url') or '';q=parse_qs(urlsplit(url).query)
  channel=p.get('channelId') or p.get('channel') or p.get('subject') or q.get('subject',[None])[0]
  if channel not in channels:issue('unknown-channel',file=str(file),channel=channel);continue
  period=q.get('date_range',[None])[0];query_year=p.get('queryYear')
  if period and re.fullmatch(r'(\d{4})-\1',period):
   derived=int(period[:4])
   if query_year is not None and query_year!=derived:issue('query-year-conflict',file=str(file),declared=query_year,derived=derived)
   query_year=derived
  elif query_year is not None:issue('missing-year-query',file=str(file),queryYear=query_year,url=url)
  if query_year is not None and query_year not in expected_years[channel]:issue('unexpected-year',file=str(file),queryYear=query_year);continue
  number=int(p.get('pageNumber') or p.get('page') or q.get('page',['1'])[0]);records=p.get('papers',p.get('records',p.get('articles',p.get('cards',[]))))
  if urlsplit(url).hostname not in ('www.nature.com','nature.com'):issue('nonofficial-query-url',file=str(file),url=url)
  if int(q.get('page',['1'])[0])!=number:issue('query-page-number-conflict',file=str(file),declared=number,url=url)
  if query_year is not None and file.name!=f'{channel}-year{query_year}-{number:03d}.json':issue('page-filename-scope-conflict',file=str(file),channel=channel,queryYear=query_year,page=number)
  try:datetime.fromisoformat(p.get('capturedAt','').replace('Z','+00:00'))
  except (ValueError,TypeError,AttributeError):issue('invalid-capture-timestamp',file=str(file),capturedAt=p.get('capturedAt'))
  expected=expected_years[channel][query_year] if query_year is not None else channels[channel]['officialResultsCount']
  key=(channel,query_year);g=groups.setdefault(key,{'pages':{},'records':{},'signatures':{},'expected':expected,'queryYear':query_year,'channel':channel})
  if number in g['pages']:issue('duplicate-page-key',file=str(file),channel=channel,queryYear=query_year,page=number)
  if urlsplit(url).path!='/search':issue('not-search-results-url',file=str(file),url=url)
  if p.get('nextPageUrl'):
   nq=parse_qs(urlsplit(p['nextPageUrl']).query)
   if nq.get('subject')!=q.get('subject') or nq.get('date_range')!=q.get('date_range') or nq.get('article_type')!=q.get('article_type') or int(nq.get('page',['-1'])[0])!=number+1:issue('next-page-scope-mismatch',file=str(file),url=url,nextPageUrl=p['nextPageUrl'])
  if q.get('subject',[None])[0]!=channel:issue('query-channel-mismatch',file=str(file),channel=channel,url=url)
  if set(q.get('article_type',[''])[0].split(','))!={'protocols','research','reviews'}:issue('query-type-scope',file=str(file),url=url)
  if q.get('journal') or q.get('journal[]'):issue('unexpected-journal-restriction',file=str(file),url=url)
  start=p.get('resultStart');end=p.get('resultEnd');total=p.get('officialTotal')
  if total!=expected:issue('official-total-drift',file=str(file),channel=channel,queryYear=query_year,observed=total,expected=expected)
  if expected==0:
   if records or start!=0 or end!=0 or 'No results were found' not in p.get('heading',''):issue('unverified-zero',file=str(file),channel=channel,queryYear=query_year)
  elif start is not None and end is not None:
   if len(records)!=end-start+1:issue('page-record-range-mismatch',file=str(file),range=[start,end],records=len(records))
   if start!=(number-1)*50+1 or end!=min(number*50,expected):issue('page-range-mismatch',file=str(file),page=number,range=[start,end])
  else:issue('missing-page-range',file=str(file))
  ids=[]
  for r in records:
   identity=canon(r.get('url') or r.get('href'))
   if not identity:issue('noncanonical-article-url',file=str(file),url=r.get('url'));continue
   ids.append(identity);obs={'record':r,'file':str(file),'page':number,'sourceUrl':url,'channel':channel,'queryYear':query_year}
   if identity in g['records']:issue('duplicate-within-query',severity='warning',channel=channel,queryYear=query_year,url=identity,pages=[g['records'][identity]['page'],number])
   else:g['records'][identity]=obs
   by_channel[channel].setdefault(identity,obs);by_paper[identity].append(obs)
   if query_year is not None:primary_by_channel[channel].setdefault(identity,obs)
   if not r.get('title') or not r.get('journal') or not r.get('type'):issue('missing-metadata',file=str(file),url=identity)
   date=r.get('date') or r.get('publicationDate');year=r.get('year')
   if not isinstance(date,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',date):issue('invalid-date',file=str(file),url=identity,date=date)
   else:
    try:calendar_date.fromisoformat(date)
    except ValueError:issue('invalid-calendar-date',file=str(file),url=identity,date=date)
    if date>DATE:issue('after-snapshot-date',url=identity,date=date)
    if year is not None and year!=int(date[:4]):issue('date-year-mismatch',url=identity,date=date,year=year)
    if query_year is not None and int(date[:4])!=query_year:issue('record-date-outside-query-year',file=str(file),url=identity,date=date,queryYear=query_year)
   if classify(r.get('type')) in ('other','unknown'):issue('unexpected-type-in-query',severity='warning',url=identity,type=r.get('type'))
   if r.get('doi') and not re.match(r'^(https://doi.org/)?10\.\d{4,9}/\S+$',r['doi']):issue('invalid-doi',url=identity,doi=r['doi'])
  signature=hashlib.sha256('\n'.join(ids).encode()).hexdigest()
  if signature in g['signatures'] and ids:issue('duplicate-entire-page',channel=channel,queryYear=query_year,pages=[g['signatures'][signature],number])
  g['signatures'][signature]=number
  g['pages'][number]={'page':number,'queryYear':query_year,'recordCount':len(records),'uniqueRecordCount':len(set(ids)),'url':url,'file':str(file),'resultStart':start,'resultEnd':end,'officialTotal':total}
 conflicts=[];doi_urls=defaultdict(set)
 for identity,obs in by_paper.items():
  for field in ['title','date','year','type','journal','doi']:
   vals={json.dumps(o['record'].get(field),ensure_ascii=False) for o in obs if o['record'].get(field) is not None}
   if len(vals)>1:conflicts.append({'url':identity,'field':field,'values':sorted(vals),'sources':list(dict.fromkeys(o['sourceUrl'] for o in obs))})
  for o in obs:
   if o['record'].get('doi'):doi_urls[o['record']['doi'].lower().removeprefix('https://doi.org/')].add(identity)
 result_channels=[];page_metadata={}
 for slug,ch in channels.items():
  obs=list(by_channel[slug].values());primary=list(primary_by_channel[slug].values());types=Counter();year_types=defaultdict(Counter);dates=Counter()
  for o in obs:
   r=o['record'];year=r.get('year') or (int(r['date'][:4]) if r.get('date') else None);typ=classify(r.get('type'));dates[year]+=1;types[typ]+=1;year_types[year][typ]+=1
  year_stats=[]
  for year,expected in sorted(expected_years[slug].items()):
   g=groups.get((slug,year));nums=sorted(g['pages']) if g else [];needed=max(1,(expected+49)//50);retrieved=len(g['records']) if g else 0;missing=[i for i in range(1,needed+1) if i not in nums]
   year_stats.append({'year':year,'expected':expected,'retrieved':retrieved,'difference':retrieved-expected,'paperDateCountAcrossAllQueries':dates[year],'queryCaptured':g is not None,'complete':g is not None and retrieved==expected and not missing,'pages':nums,'missingPages':missing,'expectedPages':needed})
  primary_pages=[p for (c,y),g in groups.items() if c==slug and y is not None for p in g['pages'].values()];supplemental=[p for (c,y),g in groups.items() if c==slug and y is None for p in g['pages'].values()]
  page_metadata[slug]=primary_pages+supplemental
  result_channels.append({'id':slug,'expectedTotal':ch['officialResultsCount'],'retrievedUnique':len(obs),'primaryRetrievedUnique':len(primary),'remaining':ch['officialResultsCount']-len(obs),'countMatches':len(obs)==ch['officialResultsCount'],'annualCountsMatch':all(y['queryCaptured'] and y['difference']==0 for y in year_stats),'primaryComplete':all(y['complete'] for y in year_stats),'primaryPagesCaptured':len(primary_pages),'expectedPrimaryPages':sum(y['expectedPages'] for y in year_stats),'supplementalPagesCaptured':len(supplemental),'pages':[{'year':p['queryYear'],'page':p['page']} for p in primary_pages+supplemental],'typeCounts':dict(types),'yearTypeCounts':{str(y):dict(t) for y,t in sorted(year_types.items(),key=lambda x:str(x[0]))},'years':year_stats})
 errors=[i for i in issues if i['severity']=='error']
 return {'checkedDate':DATE,'pageFiles':len(pages),'primaryPagesCaptured':sum(c['primaryPagesCaptured'] for c in result_channels),'expectedPrimaryPages':sum(c['expectedPrimaryPages'] for c in result_channels),'supplementalPagesCaptured':sum(c['supplementalPagesCaptured'] for c in result_channels),'uniquePapers':len(by_paper),'channelMemberships':sum(len(v) for v in by_channel.values()),'multiChannelPapers':sum(len({o['channel'] for o in obs})>1 for obs in by_paper.values()),'complete':all(c['countMatches'] and c['primaryComplete'] for c in result_channels) and not errors,'channels':result_channels,'metadataConflicts':conflicts,'doiMultipleUrls':{d:sorted(u) for d,u in doi_urls.items() if len(u)>1},'issues':issues,'pages':page_metadata}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--pages-dir',type=Path,default=BASE/'pages');ap.add_argument('--baseline',type=Path,default=DEFAULT_BASELINE);ap.add_argument('--output',type=Path,default=BASE/'corpus-audit.json');args=ap.parse_args();result=audit(args.pages_dir,args.baseline);args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps({k:result[k] for k in ['pageFiles','primaryPagesCaptured','expectedPrimaryPages','uniquePapers','channelMemberships','multiChannelPapers','complete']},indent=2));print(json.dumps([{k:c[k] for k in ['id','expectedTotal','retrievedUnique','primaryRetrievedUnique','primaryComplete','primaryPagesCaptured','expectedPrimaryPages']} for c in result['channels']],indent=2));print('issues',len(result['issues']),'metadata conflicts',len(result['metadataConflicts']))

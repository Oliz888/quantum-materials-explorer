# Nature subject corpus · 4 November 2026

Five Nature Portfolio subject channels; publication years 2010–2026 (2026 partial, through November 4). Only the official research, reviews and protocols search groups are included. The separate citation-topic channel, news/comment records, WoS and funding data are outside this collection.

Each JSON under pages/ is bibliographic metadata as displayed on one official Nature search page, with the exact query URL, result range, timestamp and canonical article links. There are 85 single-year searches and 420 pages including two explicit no-results pages. A single unrestricted search cannot expose more than 1,000 results. Year partitions remain below this cap. Date-order checks replaced two unstable relevance-order runs; only the reconciled captures are present.

To reproduce offline: extract this archive, then run `python3 build-corpus.py` (Python 3.9+). It uses the preserved baseline.json only for the annual reference counts, source links and previously verified DOI evidence. It writes full-corpus.json and corpus-audit.json next to the script. For an independent capture-file integrity check, run `shasum -a 256 -c primary-pages.sha256` from the extracted folder. The website corpus.json holds the same data as full-corpus.json, with compact JSON formatting.

Paper identity is the canonical Nature article URL. Every paper-to-subject membership is backed by its own source search page. Type counts across all channels deduplicate by URL. This is a dated publisher-index snapshot, not a census of quantum-materials research or a citation graph.
